-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2019 at 09:01 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internship`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicant`
--

CREATE TABLE `applicant` (
  `company_name` varchar(30) DEFAULT NULL,
  `google` varchar(30) NOT NULL,
  `fb` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicant`
--

INSERT INTO `applicant` (`company_name`, `google`, `fb`) VALUES
('mo', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `student_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`student_id`) VALUES
('mo');

-- --------------------------------------------------------

--
-- Table structure for table `applied`
--

CREATE TABLE `applied` (
  `google` varchar(30) DEFAULT NULL,
  `aait5` varchar(30) DEFAULT NULL,
  `hilcoe` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applied`
--

INSERT INTO `applied` (`google`, `aait5`, `hilcoe`) VALUES
('mo', NULL, NULL),
('ma', NULL, NULL),
('ti', NULL, NULL),
('do', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `name` varchar(30) NOT NULL,
  `id` varchar(15) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `email_address` varchar(30) DEFAULT NULL,
  `street_number` varchar(15) DEFAULT NULL,
  `street_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`name`, `id`, `phone_number`, `email_address`, `street_number`, `street_name`) VALUES
('google', '121', '515155', 'vgjhb', '651', 'b v n'),
('oracle', '641565', '+5316156', 'djfb3vbh', '265625', 'vh4ds'),
('facebook', '64165', '+516156', 'djfbvbh', '26525', 'vhds'),
('aait', 'aau', '+25154544545', 'gfds@df.dgshc', '457', 'king george'),
('hilcoe', 'hil', '+251524544545', 'gfdas@df.dgshc', '4157', 'kingGeorge');

-- --------------------------------------------------------

--
-- Table structure for table `postedjobs`
--

CREATE TABLE `postedjobs` (
  `Company_ID` varchar(15) DEFAULT NULL,
  `Title` varchar(15) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Min_GPA` float NOT NULL,
  `Salary` float NOT NULL,
  `Deadline` date DEFAULT NULL,
  `Posted_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postedjobs`
--

INSERT INTO `postedjobs` (`Company_ID`, `Title`, `Description`, `Min_GPA`, `Salary`, `Deadline`, `Posted_Date`) VALUES
('ibm', 'hacker', 'we need a black hat hacker', 3.72, 15200.5, '2019-05-02', '2019-01-20'),
('hil332', 'pro', 'bcx jc bhcdj bchdfb hbsd', 3.22, 1850.25, '2019-05-22', '2019-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `studentid` varchar(30) NOT NULL,
  `google` varchar(30) DEFAULT NULL,
  `aait5` varchar(30) DEFAULT NULL,
  `hilcoe` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`studentid`, `google`, `aait5`, `hilcoe`) VALUES
('tr', 'rejected', 'rejected', 'rejected'),
('ghdw', 'rejected', 'accepted', 'accepted'),
('ab', 'rejected', 'rejected', 'accepted'),
('cd', 'rejected', 'rejected', 'accepted'),
('xe', 'rejected', 'rejected', 'accepted'),
('cds', 'rejected', 'rejected', 'accepted'),
('cddss', 'rejected', 'rejected', 'accepted');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `name` varchar(30) NOT NULL,
  `id` varchar(15) NOT NULL,
  `password` varchar(30) NOT NULL,
  `cgpa` float NOT NULL,
  `year` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`name`, `id`, `password`, `cgpa`, `year`) VALUES
('moti', 'mo', '456', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `name` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`name`) VALUES
('salo'),
('lolo'),
('lala'),
('salo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicant`
--
ALTER TABLE `applicant`
  ADD KEY `company_name` (`company_name`);

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `phone` (`phone_number`),
  ADD UNIQUE KEY `phone_2` (`phone_number`),
  ADD UNIQUE KEY `email_address` (`email_address`);

--
-- Indexes for table `postedjobs`
--
ALTER TABLE `postedjobs`
  ADD UNIQUE KEY `Company_ID` (`Company_ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applicant`
--
ALTER TABLE `applicant`
  ADD CONSTRAINT `applicant_ibfk_1` FOREIGN KEY (`company_name`) REFERENCES `student` (`id`);

--
-- Constraints for table `applicants`
--
ALTER TABLE `applicants`
  ADD CONSTRAINT `applicants_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
